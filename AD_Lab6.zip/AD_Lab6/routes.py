from flask import render_template, request, redirect, url_for, flash
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

class User(UserMixin):
    def __init__(self, id, username, email):
        self.id = id
        self.username = username
        self.email = email

def init_routes(app, mysql, bcrypt, login_manager):
    @login_manager.user_loader
    def load_user(user_id):
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username, email FROM users WHERE id = %s", (user_id,))
        user_data = cur.fetchone()
        cur.close()
        return User(user_data["id"], user_data["username"], user_data["email"]) if user_data else None

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/signup", methods=["GET", "POST"])
    def signup():
        if request.method == "POST":
            username = request.form["username"]
            email = request.form["email"]
            password = bcrypt.generate_password_hash(request.form["password"]).decode("utf-8")

            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, password))
            mysql.connection.commit()
            cur.close()

            flash("Signup successful! Please log in.", "success")
            return redirect(url_for("login"))
        return render_template("signup.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form["email"]
            password = request.form["password"]

            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM users WHERE email = %s", (email,))
            user_data = cur.fetchone()
            cur.close()

            if user_data and bcrypt.check_password_hash(user_data["password"], password):
                user = User(user_data["id"], user_data["username"], user_data["email"])
                login_user(user)
                flash("Login successful!", "success")
                return redirect(url_for("dashboard"))
            else:
                flash("Invalid email or password", "danger")

        return render_template("login.html")

    # @app.route("/dashboard")
    # @login_required
    # def dashboard():
    #     return render_template("dashboard.html", username=current_user.username)
    @app.route("/dashboard")
    @login_required
    def dashboard():
        cur = mysql.connection.cursor()
        cur.execute("SELECT subject, marks FROM grades WHERE user_id = %s", (current_user.id,))
        grades_data = cur.fetchall()  # Fetch all rows
    
    # Convert the fetched dictionary to a list of tuples
        grades_list = [(row["subject"], row["marks"]) for row in grades_data]

        cur.close()

        return render_template("dashboard.html", username=current_user.username, grades=grades_list)


    @app.route("/update_profile", methods=["GET", "POST"])
    @login_required
    def update_profile():
        if request.method == "POST":
            new_username = request.form["username"]
            new_email = request.form["email"]

            cur = mysql.connection.cursor()
            cur.execute("UPDATE users SET username = %s, email = %s WHERE id = %s",
                        (new_username, new_email, current_user.id))
            mysql.connection.commit()
            cur.close()

            flash("Profile updated successfully!", "success")
            return redirect(url_for("dashboard"))

        return render_template("update_profile.html")

    @app.route("/reset_password", methods=["GET", "POST"])
    @login_required
    def reset_password():
        if request.method == "POST":
            current_password = request.form["current_password"]
            new_password = request.form["new_password"]

            cur = mysql.connection.cursor()
            cur.execute("SELECT password FROM users WHERE id = %s", (current_user.id,))
            user_data = cur.fetchone()

            if user_data and bcrypt.check_password_hash(user_data["password"], current_password):
                hashed_password = bcrypt.generate_password_hash(new_password).decode("utf-8")
                cur.execute("UPDATE users SET password = %s WHERE id = %s",
                            (hashed_password, current_user.id))
                mysql.connection.commit()
                cur.close()

                flash("Password updated successfully!", "success")
                return redirect(url_for("dashboard"))
            else:
                flash("Current password is incorrect.", "danger")

        return render_template("reset_password.html")

    @app.route("/grades")
    @login_required
    def grades():
        cur = mysql.connection.cursor()
        cur.execute("SELECT subject, marks FROM grades WHERE user_id = %s", (current_user.id,))
        grades_data = cur.fetchall()
        cur.close()
    
        return render_template("grades.html", grades=grades_data)


    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("Logged out successfully.", "info")
        return redirect(url_for("login"))
