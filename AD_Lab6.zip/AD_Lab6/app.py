from flask import Flask
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from routes import init_routes

app = Flask(__name__)
app.config.from_object("config")

mysql = MySQL(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

init_routes(app, mysql, bcrypt, login_manager)

if __name__ == "__main__":
    app.run(debug=True)
