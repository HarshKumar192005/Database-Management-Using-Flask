import os

SECRET_KEY = os.urandom(24)

MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""
MYSQL_DB = "user_db"
MYSQL_CURSORCLASS = "DictCursor"
